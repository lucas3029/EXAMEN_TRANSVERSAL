def validar_codigo(codigo, peliculas):
    if not codigo.strip() or codigo.upper() in peliculas:
        return False
    return True

def validar_titulo(titulo):
    return bool(titulo.strip())

def validar_genero(genero):
    return bool(genero.strip())

def validar_duracion(duracion):
    try:
        duracion = int(duracion)
        return duracion > 0
    except ValueError:
        return False

def validar_clasificacion(clasificacion):
    return clasificacion.upper() in ['A', 'B', 'C']

def validar_idioma(idioma):
    return bool(idioma.strip())

def validar_es_3d(es_3d_str):
    return es_3d_str.lower() in ['s', 'n']

def validar_precio(precio):
    try:
        precio = int(precio) 
        return precio > 0
    except ValueError:
        return False

def validar_cupos(cupos):
    try:
        cupos = int(cupos)
        return cupos >= 0
    except ValueError:
        return False


def leer_opcion():
    try:
        opcion = int(input("Ingrese opción: "))
        if opcion >= 1 and opcion <= 6:
            return opcion
        else:
            print("debe seleccionar una opcion valida.")
            return None
    except ValueError:
        print("debe seleccionar una opcion valida.")
        return None


def cupos_genero(genero, peliculas, cartelera):
    genero_buscado = genero.strip().lower()
    total_cupos = 0
    
    for codigo, datos in peliculas.items():
        if datos[1].lower() == genero_buscado:
            total_cupos += cartelera[codigo][1]
            
    print(f"El total de cupos disponibles es: {total_cupos}")


def busqueda_precio(p_min, p_max, peliculas, cartelera):
    resultados = []
    
    for codigo, datos_cartelera in cartelera.items():
        precio = datos_cartelera[0]
        cupos = datos_cartelera[1]
        
        if p_min <= precio <= p_max and cupos > 0:
            titulo = peliculas[codigo][0]
            resultados.append(f"{titulo}--{codigo}")
            
    if resultados:
        resultados.sort()
        print(f"peliculas encontradas son: {resultados}")
    else:
        print("no hay peliculas en ese rango de precios.")


def buscar_codigo(codigo, diccionario):
    return codigo.upper() in diccionario


def actualizar_precio(codigo, nuevo_precio, cartelera):
    if buscar_codigo(codigo, cartelera):
        cartelera[codigo.upper()][0] = nuevo_precio
        return True
    return False


def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos, peliculas, cartelera):
    codigo_upper = codigo.upper()
    if codigo_upper in peliculas:
        return False
        
    es_3d_bool = True if es_3d.lower() == 's' else False
    
    peliculas[codigo_upper] = [titulo.strip(), genero.strip(), int(duracion), clasificacion.upper(), idioma.strip(), es_3d_bool]
    cartelera[codigo_upper] = [int(precio), int(cupos)]
    return True


def eliminar_pelicula(codigo, peliculas, cartelera):
    codigo_upper = codigo.upper()
    if buscar_codigo(codigo_upper, peliculas):
        peliculas.pop(codigo_upper)
        cartelera.pop(codigo_upper)
        return True
    return False

def main():
    peliculas = {'P101': ['Luz de Otoño', 'drama', 110, 'B', 'Español', False],
    'P102': ['Noche Neon', 'accion', 125, 'C', 'Ingles', True],
    'P103': ['Planeta Agua', 'documental', 90, 'A', 'Español', False],
    'P104': ['Risa Total', 'comedia', 105, 'A', 'Español', True],
    'P105': ['Codigo Zero', 'thriller', 118, 'C', 'Ingles', True],
    'P106': ['Viaje Lunar', 'ciencia ficcion', 132, 'B', 'Ingles', False]
    }

    cartelera = {'P101': [5990, 40],'P102': [7990, 0],'P103': [4990, 25],'P104': [6990, 12],'P105': [8990, 8],'P106': [7490, 3]
    }

    while True:
        print("===== MENU PRINCIPAL =====")
        print("1. cupos por genero")
        print("2. busqueda de peliculas por rango de precio")
        print("3. actualizar el precio de pelicula")
        print("4. agregar peliculas")
        print("5. eliminar peliculas")
        print("6. salir del menu")
        
        opcion = leer_opcion()
        
        if opcion == 6:
            print("Programa finalizando.")
            break
            
        elif opcion == 1:
            genero = input("Ingrese el genero a consultar: ")
            cupos_genero(genero, peliculas, cartelera)
            
        elif opcion == 2:
            while True:
                try:
                    preciomin = int(input("ingrese el precio minimo: "))
                    preciomax = int(input("ingrese el precio maximo: "))
                    if preciomin >= 0 and preciomax >= preciomin:
                        busqueda_precio(preciomin, preciomax, peliculas, cartelera)
                        break
                    else:
                        print("valor invalido deben ser mayor a 0.")
                except ValueError:
                    print("se debe ingresar valores enteros")
                    
        elif opcion == 3:
            while True:
                codigo = input("Ingrese el coddigo de la pelicula: ")
                try:
                    nuevo_precio = int(input("ingrese nuevo precio: "))
                    if nuevo_precio <= 0:
                        print("El precio debe ser mayor a cero.")
                        
                except ValueError:
                    print("se debe ingresar un valor entero.")
                    
                if actualizar_precio(codigo, nuevo_precio, cartelera):
                    print("Precio actualizado")
                else:
                    print("El codigo no existe")
                    
                resp = input("desea actualizar otro precio (s/n)?: ").strip().lower()
                if resp != 's':
                    break
                    
        elif opcion == 4:
            codigo = input("ingrese el codigo de la pelicula: ")
            if not validar_codigo(codigo, peliculas):
                print("error el codigo es invalido o ya existe.")
                
                
            titulo = input("ingrese titulo: ")
            if not validar_titulo(titulo):
                print("error: El titulo no puede estar vacio.")
                
                
            genero = input("ingrese genero: ")
            if not validar_genero(genero):
                print("error: El gneero no puede estar vacio.")
                
                
            duracion = input("ingrese duracion (en minutos): ")
            if not validar_duracion(duracion):
                print("error la duracion debe ser mayor a cero.")
                
                
            clasificacion = input("Ingrese clasificacion: ")
            if not validar_clasificacion(clasificacion):
                print("Error: La clasificacion debe ser exactamente 'A', 'B' o 'C'.")
                
                
            idioma = input("Ingrese idioma: ")
            if not validar_idioma(idioma):
                print("idioma invalido, el idioma no puede estar vacio.")
                
                
            es_3d = input("¿es 3d? (s/n): ")
            if not validar_es_3d(es_3d):
                print("Error: Debe ingresar 's' o 'n'.")
                
                
            precio = input("Ingrese precio: ")
            if not validar_precio(precio):
                print(" el precio debe ser un numero entero mayor que cero.")
               
                
            cupos = input("ingrese cupos: ")
            if not validar_cupos(cupos):
                print("error los cupos deben ser mayor que cero.")
                
                
            if agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos, peliculas, cartelera):
                print("la pelicula a sido agregada exitosamente.")
            else:
                print("El codigo ya existe")
                
        elif opcion == 5:
            codigo = input("ingrese cdigo de la pelicula a eliminar: ")
            if eliminar_pelicula(codigo, peliculas, cartelera):
                print("Pelicula eliminada correctamente")
            else:
                print("El codigo no existe")
if __name__ == "__main__":
    main()